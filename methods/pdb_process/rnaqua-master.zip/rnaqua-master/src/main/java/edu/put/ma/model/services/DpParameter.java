package edu.put.ma.model.services;

public interface DpParameter {

    String toString();
    
    String getName();
}
