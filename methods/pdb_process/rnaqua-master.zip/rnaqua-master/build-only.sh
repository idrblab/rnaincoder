#!/bin/bash
mvn package -DskipTests