#!/bin/bash
mvn package -DskipTests -P java-8
