#!/bin/sh
mvn package -P java-8
