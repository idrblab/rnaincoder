package edu.put.ma.model.input;

public interface AnalysisInputModel extends CommonInputModel {

    boolean isValid();
}
