#!/bin/sh
mvn package